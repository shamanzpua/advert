<div class="form-group">
    <label>{{ $label }}</label>
    <input {!! $attributes !!}>
</div>