<div class="{{$viewClass['form-group']}}">

    <label class="{{$viewClass['label']}} control-label"></label>

    <div class="{{$viewClass['field']}}">
        <input type='button' value='{{$label}}' class="btn {{ $class }}" {!! $attributes !!} />
    </div>
</div>